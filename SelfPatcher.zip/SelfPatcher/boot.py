from __future__ import annotations

import sublime

SUPPORTED_PLATFORM_ARCHS = {
    "linux-x64",
    "windows-x64",
}

if (sublime.platform() + "-" + sublime.arch()) in SUPPORTED_PLATFORM_ARCHS:
    from .plugin import *  # noqa: F403
else:
    print(f"[INFO] SelfPackage only works on these platform/arch: {', '.join(SUPPORTED_PLATFORM_ARCHS)}")
