from __future__ import annotations

import sublime

THIS_PLATFORM_ARCH = sublime.platform() + "-" + sublime.arch()
SUPPORTED_PLATFORM_ARCHS = {
    "linux-x64",
    "windows-x64",
}

if THIS_PLATFORM_ARCH in SUPPORTED_PLATFORM_ARCHS:
    from .plugin import *  # noqa: F403
else:
    print(f"[INFO] SelfPackage only works on these platform/arch: {', '.join(SUPPORTED_PLATFORM_ARCHS)}")
