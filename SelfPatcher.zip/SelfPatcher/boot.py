import sublime

if sublime.platform() == "windows" and sublime.arch() == "x64":
    from .plugin import *  # noqa: F403
else:
    print("[INFO] SelfPackage only works on Windows x64.")
