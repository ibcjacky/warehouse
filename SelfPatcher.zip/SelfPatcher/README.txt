Put this "SelfPatcher" folder into Sublime Text's "Packages" folder and restart Sublime Text.

* Plugin author: n6333373
* Credits      : bad1dea, leogx9r, urxi
